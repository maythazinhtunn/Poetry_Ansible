from functools import lru_cache

from pydantic_settings import BaseSettings
# from pydantic import BaseSettings


class Settings(BaseSettings):
    """Application runtime settings to configure via env"""

    factory_resource_manager_url: str = "factory_resource_manager_url"
    server_host: str = "server_host"
    server_port: str = "server_port"
    if_config: str = "interface"

    class Config:
        env_file = ".env"


@lru_cache
def get_settings() -> Settings:
    return Settings()
