import os
import subprocess

from netaddr import EUI, mac_unix_expanded

from pt_agent.config import Settings, get_settings

settings: Settings = get_settings()


def get_terminal_mac():
    mac_address = os.environ.get("MAC_ADDRESS")
    if mac_address:
        return mac_address_unix_format(mac_address)
    else:
        output = subprocess.check_output(["ifconfig", settings.if_config]).decode(
            "utf-8"
        )
        mac_address = output.split("ether ")[1].split()[0]
        if mac_address:
            return mac_address_unix_format(mac_address)
        else:
            return None


def mac_address_unix_format(mac):
    mac = EUI(mac, dialect=mac_unix_expanded)
    mac_string = str(mac).replace(":", "")
    return mac_string
