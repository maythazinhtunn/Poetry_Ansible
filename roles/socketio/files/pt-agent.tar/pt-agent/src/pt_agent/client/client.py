import socketio
from utils import get_terminal_mac

from pt_agent.config import Settings, get_settings

settings: Settings = get_settings()

sio = socketio.Client()

terminal_id = get_terminal_mac()
socket_server_url = f"http://{settings.server_host}:{settings.server_port}"


@sio.on("connect")
def connect():
    print(f"Connected to server as {terminal_id}")
    sio.emit("tclient_connected", {"tid": terminal_id})


@sio.on("disconnect")
def on_disconnect():
    print("Disconnected from server")


# Event handler for "status" event
@sio.on("status")
def status_event(data):
    tid = data.get("tid")
    message = data.get("message")
    print(f"Terminal {tid}: {message}")


def main():
    sio.connect(socket_server_url)
    try:
        sio.wait()
    except KeyboardInterrupt:
        sio.disconnect()


if __name__ == "__main__":
    main()
