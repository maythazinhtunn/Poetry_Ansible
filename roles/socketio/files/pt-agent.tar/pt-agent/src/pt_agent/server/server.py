import sys

import requests
import socketio
from aiohttp import web

from pt_agent.config import Settings, get_settings

settings: Settings = get_settings()

# Initialize aiohttp web application
app = web.Application()

# Initialize Socket.IO server
sio = socketio.AsyncServer(cors_allowed_origins="*")
sio.attach(app)

# Dictionary to store device IDs and their corresponding sockets
device_sockets = {}

# URL to update status
status_update_url = settings.factory_resource_manager_url


async def update_status(tid, status):
    try:
        patch_data = [{"op": "replace", "path": "/status", "value": status}]
        response = requests.patch(f"{status_update_url}/{tid}", json=patch_data)
        if response.status_code == 200:
            print(f"Status updated to '{status}' for Terminal {tid}")
        else:
            print(f"Failed to update status for Terminal {tid}")
    except requests.exceptions.Timeout:
        # Timeout occurred
        print("Send terminal status fail.")
        sys.exit(1)
    except requests.exceptions.RequestException as _:
        print("Send terminal status fail")


@sio.event
async def connect(sid, environ):
    device_sockets[sid] = {}  # Initialize dictionary for this sid
    print(f"Client connected: {sid}")


@sio.event
async def disconnect(sid):
    if sid in device_sockets:
        tid = device_sockets[sid].get("tid")
        if tid:
            print(f"Terminal {tid} is offline")
            await update_status(tid, "offline")
            await sio.emit("status", {"tid": tid, "message": "offline"})
        del device_sockets[sid]  # Delete the entry for this sid


@sio.event
async def tclient_connected(sid, data):
    if tid := data.get("tid"):
        print(f"Terminal {tid} is online")
        await update_status(tid, "online")
        if sid in device_sockets:
            device_sockets[sid]["tid"] = tid
            device_sockets[sid]["status"] = True
        print(f"Terminal {data.get('tid')} connected. {data.get('tid')} is online.")
        await sio.emit("status", {"tid": data.get("tid"), "message": "online"})


if __name__ == "__main__":
    web.run_app(app, host="0.0.0.0", port="5000")
