#!/usr/bin/env python

from pcf.utils import *

# print(parse_mac('_gateway (192.168.99.1) at 28:30:ac:60:4a:a7 [ether] on wlp3s0'))
# print(parse_mac('_gateway'))
print(lookup_mac_with_ip('192.168.99.1', t_sec=5))