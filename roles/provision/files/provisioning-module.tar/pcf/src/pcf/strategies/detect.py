from abc import ABC, abstractclassmethod
from pcf.cpe import FRONTIIR_CPE
from pcf.config import Settings,get_settings
from pcf.utils import (
    get_model,
    get_model_cpems,
    remove_known_hosts_entry,
    lookup_mac_with_ip,
    look_up_detail_from_cpems,
    look_up_from_cpems
)
from pcf.eventlog import Logger

settings: Settings = get_settings()
log: Logger = Logger()

class DetectModelStrategies(ABC):
    @abstractclassmethod
    def detect_model(self,ip: str):
        raise NotImplementedError

    @abstractclassmethod
    def provision_detect_model(self,ip: str):
        raise NotImplementedError


class FCPEDetectStrategies(DetectModelStrategies):
    def __init__(self) -> None:
        self.username = "root"
        self.default_password = "7890"
        self.default_ip = ""
        self.provisioned_ip = ""

    def detect_model(self,ip: str="192.168.1.2"):
        self.default_ip = ip
        fcpe = FRONTIIR_CPE(
                self.default_ip, ssh_password=self.default_password
            )
        remove_known_hosts_entry(ip_address=ip)
        mac = lookup_mac_with_ip(self.default_ip, t_sec=3) 

        # get cpe model from cpems       
        cpems = look_up_from_cpems(mac)
        if cpems and (cid :=cpems.get('cid')):           
            device_model=look_up_detail_from_cpems(cid).get('model')

        model = get_model_cpems(device_model)

        # get cpe model from cpe
        if not model:
            device_model=fcpe.detect_model()
            model = get_model(device_model)

        if model:
            return model
        else:
            model = "Unknown model"
            return model
    
    def provision_detect_model(self,ip: str="192.168.99.1"):
        self.provisioned_ip = ip
        remove_known_hosts_entry(ip_address=self.provisioned_ip)
        mac = lookup_mac_with_ip(self.provisioned_ip, t_sec=3)        
        cpems = look_up_from_cpems(mac)
        if cpems and (cid :=cpems.get('cid')):           
            device_model=look_up_detail_from_cpems(cid).get('model')
        
        model = get_model_cpems(device_model)
        if model:
            return model
        else:
            model = "Unknown model"
            return model
        
class UbiquitiDetectStrategies(DetectModelStrategies):
    def __init__(self) -> None:
        self.username = "ubnt"
        self.default_password = "ubnt"
        self.default_ip = ""
        self.provisioned_ip = ""
        
    def detect_model(self,ip: str="192.168.1.1"):
        self.default_ip = ip

        remove_known_hosts_entry(ip_address=ip)
        mac = lookup_mac_with_ip(self.default_ip, t_sec=3) 

        # get cpe model from cpems       
        cpems = look_up_from_cpems(mac)
        if cpems and (cid :=cpems.get('cid')):           
            device_model=look_up_detail_from_cpems(cid).get('model')

        model = get_model_cpems(device_model)

        # get cpe model from cpe
        if not model:
            # device_model=ubnt_cpe.detect_model()
            # model = get_model(device_model)
            model = input("Please enter cpe model detected by Terminal:")

        if model:
            return model
        else:
            model = "Unknown model"
            return model
    
    def provision_detect_model(self,ip: str="192.168.99.1"):
        self.provisioned_ip = ip
        remove_known_hosts_entry(ip_address=self.provisioned_ip)
        mac = lookup_mac_with_ip(self.provisioned_ip, t_sec=3)        
        cpems = look_up_from_cpems(mac)
        if cpems and (cid :=cpems.get('cid')):           
            device_model=look_up_detail_from_cpems(cid).get('model')
        
        model = get_model_cpems(device_model)
        if model:
            return model
        else:
            model = "Unknown model"
            return model

class ScsoDetectStrategies(DetectModelStrategies):
    def __init__(self) -> None:
        self.username = "ubnt"
        self.default_password = "ubnt"
        self.default_ip = ""
        self.provisioned_ip = ""
        
    def detect_model(self,ip: str="192.168.1.1"):
        self.default_ip = ip

        remove_known_hosts_entry(ip_address=ip)
        mac = lookup_mac_with_ip(self.default_ip, t_sec=3) 

        # get cpe model from cpems       
        cpems = look_up_from_cpems(mac)
        if cpems and (cid :=cpems.get('cid')):           
            device_model=look_up_detail_from_cpems(cid).get('model')

        model = get_model_cpems(device_model)

        # get cpe model from cpe
        if not model:
            # device_model=scso_cpe.detect_model()
            # model = get_model(device_model)
            model = input("Please enter cpe model detected by Terminal:")

        if model:
            return model
        else:
            model = "Unknown model"
            return model
    
    def provision_detect_model(self,ip: str="192.168.80.1"):
        self.provisioned_ip = ip
        remove_known_hosts_entry(ip_address=self.provisioned_ip)
        mac = lookup_mac_with_ip(self.provisioned_ip, t_sec=3)        
        cpems = look_up_from_cpems(mac)
        if cpems and (cid :=cpems.get('cid')):           
            device_model=look_up_detail_from_cpems(cid).get('model')
        
        model = get_model_cpems(device_model)
        if model:
            return model
        else:
            model = "Unknown model"
            return model
    
class Detect_Model_Manager:
    def __init__(self, strategy: DetectModelStrategies) -> None:
        self.strategy = strategy

    def detect_model(self,ip: str):
        return self.strategy.detect_model(ip)
    
    def provision_detect_model(self,ip: str):
        return self.strategy.provision_detect_model(ip)