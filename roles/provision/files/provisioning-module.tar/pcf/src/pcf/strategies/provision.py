from abc import ABC, abstractclassmethod
import re
import time
import os
from structlog.contextvars import(
    bind_contextvars,
)

from pcf.config import Settings, get_settings
from pcf.eventlog import Logger
from pcf.cpe import FRONTIIR_CPE,UBNT_CPE,SCSO_CPE
from pcf.utils import (
    generate_cid_on_cpems,
    generate_sid_on_cpems,
    bind_cpe_ott,
    assign_zone,
    get_cpe_config,
    get_uniq_pwd,
    check_ddr,
    uboot_fix,
    get_update_firmware,
    get_update_script,
    has_service,
    until_ok,
    get_provisioned_ip,
    look_up_from_cpems,
    lookup_mac_with_ip,
    config_reset_on_cpems,
    ping,
    provision_cpe_info,
    get_timeout,
    print_label,
)

settings: Settings = get_settings()
log: Logger = Logger()

class ProvisionStrategy(ABC):
    @abstractclassmethod
    def make(self, model: str):
        raise NotImplementedError


class FCPEProvisionStrategy(ProvisionStrategy):
    def __init__(self) -> None:
        self.username = "root"
        self.default_password = "7890"
        self.default_ip = "192.168.1.2"
        self.provisioned_ip = "192.168.99.1"
        self.mac = None
        self.provisioned_password = None
        self.is_factory_state = True
        self.is_reprovision = False

    def make(self, model: str):
        # preparation jobs
      
        # Step1. lookup mac and clear script if device is already provisioned
        bind_contextvars(model=model)
        try:
            until_ok(ping, self.default_ip,  msg1 = "Device detection with default_ip")            
        except TimeoutError:
            self.is_factory_state = False

        if get_provisioned_ip(model):
            self.provisioned_ip = get_provisioned_ip(model)

        if not self.is_factory_state:
            until_ok(ping, self.provisioned_ip, msg1 = "Device detection with provisioned_ip")
            self.mac = lookup_mac_with_ip(self.provisioned_ip, t_sec=3)
            self.provisioned_password = get_uniq_pwd(self.mac)
            config_reset_on_cpems(self.mac) #factory reset on cpems
            print("Clear script.....")
            fcpe = FRONTIIR_CPE(
                self.provisioned_ip, ssh_password=self.provisioned_password
            )
            fcpe.clear_script()
            time.sleep(120)
            until_ok(ping, self.default_ip, timeout=200,  msg1 = "Clear provision script")

        if not self.mac:
            self.mac = lookup_mac_with_ip(self.default_ip, t_sec=3)
        bind_contextvars(mac = self.mac)

        # Step2. Check re-provision and generate cid on cpems
        cpems = look_up_from_cpems(self.mac)
        if cpems and cpems.get('cid'):
            bind_contextvars(task = "re-provision")
            log.log_info("Check cid on cpems", message = "cid's already existed on cpems.")
            self.is_reprovision = True            
        else:
            generate_cid_on_cpems(self.mac, model)
            bind_contextvars(task = "provision")

        # Step3. start upgrading processes ,apply configs and set password
        fcpe = FRONTIIR_CPE(host=self.default_ip)

        #uboot process for fcgo and fcao model
        if model=="fcgo" or model=="fcao":
            time.sleep(60)
            output = check_ddr(host=self.default_ip, username=self.username, password=self.default_password)
            # output = fcpe.check_ddr()
            match = re.search(r"DDR:(\d+\.\d+)", output)
            if match:
                print("Check DDR value for uboot ........")
                ddr_val = int(float(match.group(1)))
                if ddr_val > 400:
                    uboot_fix(host=self.default_ip, username=self.username, password=self.default_password)
                    time.sleep(240)
                    until_ok(ping, self.default_ip, timeout=200,  msg1 = "Device detection with default_ip after uboot fix")
                else:
                    print("DDR value is less than 400")

            else:
                print("DDR value not found.")

          
        # upgrade firmware
        new_fw = get_update_firmware(model)
        fw_name = os.path.basename(new_fw)
        print("Firmware upgarde !!! Please wait %(timeout)s seconds." % dict(timeout= get_timeout(model)))
        fcpe.upgrade_firmware(new_fw)
        time.sleep(get_timeout(model))
        
        # wait for device up again
        until_ok(has_service, self.default_ip, timeout=200, msg1="Device detection with default_ip after firmware upgrade")
        log.log_info("Upgrade firmware", message = "Upgrade firmware success. Firmware: %(firmware)s" % dict(firmware=fw_name))

        # upgrade script
        new_sc = get_update_script(model)
        sc_name = os.path.basename(new_sc)
        print("Script update!!! Please wait.")
        fcpe.upgrade_script(new_sc)
        log.log_info("Upgrade script", message = "Upgrade script success. Script: %(script_name)s" % dict(script_name=sc_name))

        # apply config
        cpe_cfg = get_cpe_config(self.mac)
        fcpe.apply_config(cpe_cfg)
        log.log_info("Apply config", message = "Apply config success.")

        # lock device
        if not self.provisioned_password:
            self.provisioned_password = get_uniq_pwd(self.mac)
        

        fcpe.lock_device(self.provisioned_password)
        log.log_info("Unique password", message = "Unique password set success.", pwd = self.provisioned_password)

        fcpe.reboot_device(ip = self.default_ip, password=self.provisioned_password)
        time.sleep(get_timeout(model))
        until_ok(ping, self.provisioned_ip, timeout=get_timeout(model), msg1="Provision")
        print("...............Provision Success...............")
        
        #print label
        print_label(self.mac)
        
        #send provisioning cpe info status to ERP
        provision_cpe_info(self.mac,self.mac,model)


class UBNTProvisionStrategy(ProvisionStrategy):
    def __init__(self) -> None:
        self.username = "root"
        self.default_password = "letmein"
        self.default_ip = "192.168.1.2"
        self.provisioned_ip = "192.168.99.1"
        self.mac = None
        self.provisioned_password = None
        self.is_factory_state = True
        self.is_reprovision = False

    def make(self, model: str):
        # preparation jobs
      
        # Step1. lookup mac and clear script if device is already provisioned
        bind_contextvars(model=model)
        try:
            until_ok(ping, self.default_ip,  msg1 = "Device detection with default_ip")            
        except TimeoutError:
            self.is_factory_state = False
        
        if get_provisioned_ip(model):
            self.provisioned_ip = get_provisioned_ip(model)

        if not self.is_factory_state:
            until_ok(ping, self.provisioned_ip, msg1 = "Device detection with provisioned_ip")
            self.mac = lookup_mac_with_ip(self.provisioned_ip, t_sec=3)
            self.provisioned_password = get_uniq_pwd(self.mac)
            config_reset_on_cpems(self.mac) #factory reset on cpems
            print("Clear script.....")
            ubnt = UBNT_CPE(
                self.provisioned_ip, ssh_password=self.provisioned_password
            )
            ubnt.clear_script()
            time.sleep(120)
            until_ok(ping, self.default_ip, timeout=200,  msg1 = "Clear provision script")

        if not self.mac:
            self.mac = lookup_mac_with_ip(self.default_ip, t_sec=3)
        bind_contextvars(mac = self.mac)

        # Step2. Check re-provision and generate cid on cpems
        cpems = look_up_from_cpems(self.mac)
        if cpems and cpems.get('cid'):
            bind_contextvars(task = "re-provision")
            log.log_info("Check cid on cpems", message = "cid's already existed on cpems.")
            self.is_reprovision = True
        else:
            generate_cid_on_cpems(self.mac, model)
            bind_contextvars(task = "provision")

        # Step3. start upgrading processes ,apply configs and set password
        ubnt = UBNT_CPE(host=self.default_ip)

        # upgrade firmware
        new_fw = get_update_firmware(model)
        fw_name = os.path.basename(new_fw)
        print("Firmware upgarde !!! Please wait %(timeout)s seconds." % dict(timeout= get_timeout(model)))
        ubnt.upgrade_firmware(new_fw)
        time.sleep(180)
        
        # wait for device up again
        until_ok(has_service, self.default_ip, timeout=200, msg1="Device detection with default_ip after firmware upgrade")
        log.log_info("Upgrade firmware", message = "Upgrade firmware success. Firmware: %(firmware)s" % dict(firmware=fw_name))

        # upgrade script
        new_sc = get_update_script(model)
        sc_name = os.path.basename(new_sc)
        print("Script update!!! Please wait.")
        ubnt.upgrade_script(new_sc)
        log.log_info("Upgrade script", message = "Upgrade script success. Script: %(script_name)s" % dict(script_name=sc_name))

        # apply config
        cpe_cfg = get_cpe_config(self.mac)
        ubnt.apply_config(cpe_cfg)
        log.log_info("Apply config", message = "Apply config success.")

        # lock device
        if not self.provisioned_password:
            self.provisioned_password = get_uniq_pwd(self.mac)
        

        ubnt.lock_device(self.provisioned_password)
        log.log_info("Unique password", message = "Unique password set success.", pwd = self.provisioned_password)

        ubnt.reboot_device(ip = self.default_ip, password=self.provisioned_password)
        time.sleep(get_timeout(model))
        until_ok(ping, self.provisioned_ip, timeout=get_timeout(model), msg1="Provision")
        print("...............Provision Success...............")

        #print label
        print_label(self.mac)
        
        #send provisioning cpe info status to ERP
        provision_cpe_info(self.mac,self.mac,model)

class ScsoProvisionStrategy(ProvisionStrategy):
    def __init__(self) -> None:
        self.username = "root"
        self.default_password = "7890"
        self.default_ip = "192.168.1.1"
        self.ott_ip = "192.168.1.2"
        self.provisioned_ip = "192.168.99.1"
        self.mac = None
        self.ott_mac = None
        self.provisioned_password = None
        self.is_factory_state = True
        self.is_reprovision = False
        self.sid = None

    def make(self, model: str):
        # preparation jobs
      
        # Step1. lookup mac and clear script if device is already provisioned
        bind_contextvars(model=model)
        try:
            until_ok(ping, self.default_ip,  msg1 = "Device detection with default_ip") #for cpe router        
        except TimeoutError:
            self.is_factory_state = False

        if get_provisioned_ip(model):
            self.provisioned_ip = get_provisioned_ip(model)

        if not self.is_factory_state:
            until_ok(ping, self.provisioned_ip, msg1 = "Device detection with provisioned_ip")
            self.mac = lookup_mac_with_ip(self.provisioned_ip, t_sec=3)
            self.provisioned_password = get_uniq_pwd(self.mac)
            config_reset_on_cpems(self.mac) #factory reset on cpems
            print("Clear script.....")
            scso = SCSO_CPE(
                self.provisioned_ip, ssh_password=self.provisioned_password
            )
            scso.clear_script()
            time.sleep(120)
            until_ok(ping, self.default_ip, timeout=200,  msg1 = "Clear provision script")

        if not self.mac:
            self.mac = lookup_mac_with_ip(self.default_ip, t_sec=3)
        bind_contextvars(mac = self.mac)

        # Step2. Check re-provision and generate cid on cpems
        cpems = look_up_from_cpems(self.mac)
        if cpems and cpems.get('cid'):
            bind_contextvars(task = "re-provision")
            log.log_info("Check cid on cpems", message = "cid's already existed on cpems.")
            self.is_reprovision = True            
        else:
            bind_contextvars(task = "provision")
            generate_cid_on_cpems(self.mac, model)
            try:
                until_ok(ping, self.ott_ip,  msg1 = "Device detection with ott_ip") #for ott router         
            except TimeoutError:
                self.ott_ip = "192.168.99.2"
                until_ok(ping, self.ott_ip,  msg1 = "Device detection with ott_ip") #for ott router

            self.ott_mac  = lookup_mac_with_ip(self.ott_ip, t_sec=3)
            bind_contextvars(ott_mac = self.ott_mac)
            self.sid = generate_sid_on_cpems(self.mac)
            bind_cpe_ott(self.mac,self.sid)
            assign_zone(self.sid)

        # Step3. start upgrading processes ,apply configs and set password
        scso = SCSO_CPE(host=self.default_ip)

            
        # upgrade firmware
        new_fw = get_update_firmware(model)
        fw_name = os.path.basename(new_fw)
        print("Firmware upgarde !!! Please wait %(timeout)s seconds." % dict(timeout= get_timeout(model)))
        scso.upgrade_firmware(new_fw)
        time.sleep(get_timeout(model))
        
        # wait for device up again
        until_ok(has_service, self.default_ip, timeout=200, msg1="Device detection with default_ip after firmware upgrade")
        log.log_info("Upgrade firmware", message = "Upgrade firmware success. Firmware: %(firmware)s" % dict(firmware=fw_name))

        # upgrade script
        new_sc = get_update_script(model)
        sc_name = os.path.basename(new_sc)
        print("Script update!!! Please wait.")
        scso.upgrade_script(new_sc)
        log.log_info("Upgrade script", message = "Upgrade script success. Script: %(script_name)s" % dict(script_name=sc_name))

        # apply config
        cpe_cfg = get_cpe_config(self.mac)
        scso.apply_config(cpe_cfg)
        log.log_info("Apply config", message = "Apply config success.")

        # lock device
        if not self.provisioned_password:
            self.provisioned_password = get_uniq_pwd(self.mac)
        

        scso.lock_device(self.provisioned_password)
        log.log_info("Unique password", message = "Unique password set success.", pwd = self.provisioned_password)

        scso.reboot_device(ip = self.default_ip, password=self.provisioned_password)
        time.sleep(get_timeout(model))
        until_ok(ping, self.provisioned_ip, timeout=get_timeout(model), msg1="Provision")
        print("...............Provision Success...............")
        
        #print label
        print_label(self.ott_mac)
        print_label(self.mac)        
        
        #send provisioning cpe info status to ERP
        provision_cpe_info(self.mac,self.mac,model)

class ProvisionManager:
    def __init__(self, strategy: ProvisionStrategy) -> None:
        self.strategy = strategy

    def make(self, model: str):
        return self.strategy.make(model)
