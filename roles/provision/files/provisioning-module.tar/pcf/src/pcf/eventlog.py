import structlog
import logging

class Logger:
    def __init__(self):
        structlog.configure(
            processors=[        
            # structlog.stdlib.add_log_level,
            structlog.contextvars.merge_contextvars,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.JSONRenderer(sort_keys=True),
            ],
            context_class=dict,
        )
        self.logger = structlog.get_logger()

    def log_info(self, msg, **kwargs):
        self.logger.info(msg, **kwargs)

    def log_error(self, msg, **kwargs):
        self.logger.error(msg, **kwargs)

class FileLogger:
    def __init__(self, log_file):
        self.logger = logging.getLogger('file_logger')
        self.logger.setLevel(logging.DEBUG)

        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)

        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)

        self.logger.addHandler(file_handler)