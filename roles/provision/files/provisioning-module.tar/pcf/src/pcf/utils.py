# module for various utilities
import re
import shlex
import socket
import time
import subprocess
import multiprocessing 
import os
import json
import sys
from pathlib import Path
from subprocess import DEVNULL, CalledProcessError, check_call, check_output
from typing import Any, Callable
from netaddr import EUI,mac_unix_expanded
import netaddr
import requests
from structlog.contextvars import(
    bind_contextvars,
)

from pcf.config import Settings, get_settings
from pcf.eventlog import Logger
from pcf.exceptions import UniqPasswordGenFail,InvalidResponseException,FileDownloadFail
from pcf.ssh import SSH

settings: Settings = get_settings()
log: Logger = Logger()

def ping_ip(ip):
    result = subprocess.run(['ping', '-c', '2', '-w', '15', ip], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode == 0:
        return ip


def ping_ips(ips):
    pool = multiprocessing.Pool()
    processes = []

    for ip in ips:
        process = pool.apply_async(ping_ip, (ip,))
        processes.append(process)

    success_process = None

    for process in processes:
        ip = process.get()
        if ip:
            success_process = process
            break

    pool.terminate()
    pool.join()
    return success_process

def detect_ip():
    detect_ip = None
    vendor = ""
    success_process = ping_ips(settings.cpe_ip_list.split(','))

    if success_process:
        detect_ip = success_process.get()
        mac = lookup_mac_with_ip(detect_ip)
        vendor = get_cpe_org(mac=mac)
        log.log_info("Device detection", ip = detect_ip, product = vendor, message = "Device detection success")
    else:
        log.log_error("Device detection", ip = "", product = vendor, message = "Device detection fail")
        log.log_error("Model detection", message = "Model detection fail", ip = "", product = vendor, model = "")
        sys.exit(1)
    
    return detect_ip,vendor

def remove_known_hosts_entry(filepath = '/home/frontiir/.ssh/known_hosts' , ip_address = "192.168.1.2"):
    command = ['ssh-keygen', '-R', ip_address, '-f', filepath]
    subprocess.run(command,stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def get_model(device_model):
    model_mapping = {
        "FCG": "fcg",
        "FCAO": "fcao",
        "FCGO": "fcgo",
        "LCAF": "lca-f",
        "LCAC": "lca-c",
        "FCSO": "fcs-o",
        "FCGe": "fcg-e",
        "FCS": "fcs",
        "LCO": "lcb",
        "FCAC": "fca-c",
        "FCA": "sku1",
        "FCC": "fcc",
        "FCCe": "fcc-e",
    }

    return model_mapping.get(device_model)

def get_model_cpems(device_model):
    model_mapping = {
        "SKU1": "sku1",
        "FCC": "fcc",
        "FCC-E": "fcc-e",
        "FCG": "fcg",
        "FCG-E": "fcg-e",
        "FCA-C": "fca-c",
        "FCS": "fcs",
        "FCS-O": "fcs-o",
        "LCB": "lcb",
        "LCA-C": "lca-c",
        "LCA-F": "lca-f",
        "FCAO": "fcao",
        "FCGO": "fcgo",
        "NBE-M5-16": "nbe-m5-16",
        "NBE-M5-19": "nbe-m5-19",
        "AIR-GATEWAY": "air-gateway",
        "AIR-GATEWAY-LR": "air-gateway-lr",
        "AIR-ROUTER": "air-router",
        "ER-X-SFP": "er-x-sfp",
        "ER-X-SFP-R": "er-x-sfp-r",
        "ER-X": "er-x",
        "ER-X-R": "er-x-r",

    }
    return model_mapping.get(device_model)

def get_provisioned_ip(device_model):
    provisioned_ip_mapping = {
        "lcb":"192.168.100.1",
        "fcao":"192.168.80.1",
        "fcgo":"192.168.80.1",
        "fcs-o":"192.168.80.1",
        "nbe-m5-16":"192.168.100.1",
        "nbe-m5-19":"192.168.100.1",
    }
    return provisioned_ip_mapping.get(device_model)

def get_timeout(device_model):
    time_mapping = {
        "sku1":100,
        "fcc":100,
        "fcc-e":100,
        "fcg":100,
        "fcg-e":100,
        "fca-c":100,
        "fcs":100,
        "fcs-o":100,
        "lcb":100,
        "lca-c":100,
        "lca-f":100,
        "fcao":360,
        "fcgo":360,
        "nbe-m5-16":100,
        "nbe-m5-19":100,
        "air-gateway":100,
        "air-gateway-lr":100,
        "air-router":100,
        "er-x-sfp":100,
        "er-x-sfp-r":100,
        "er-x":100,
        "er-x-r":100,
    }
    return time_mapping.get(device_model)

def to_eui(mac: str) -> str:
    return str(netaddr.EUI(mac))

def get_cpe_org(mac: str) -> str:
    try:
        org = netaddr.EUI(mac).info['OUI']['org']
        return org
    except (KeyError, TypeError):
        # Handle the case when org information is not available
        return "Unknown"

def generate_cid_on_cpems(mac: str, model: str) -> None:
    api_key = settings.api_key
    action = "generate_config"
    try:
        _response = requests.get(settings.cid_generate_url.format(api_key=api_key, action= action, mac = mac, serial = mac, model = model), verify =False)
        if _response.status_code == 200:
            action = "apply_config"
            response = requests.get(settings.cid_generate_url.format(api_key=api_key, action= action, mac = mac, serial = mac, model = model),verify = False)
            if response.status_code == 200:
                log.log_info("Generate cid on cpems", message = "Generate cid on cpems success")
                return True
            else:
               log.log_error("Generate cid on cpems", message = "Generate cid on cpems fail")
               response.raise_for_status()
               sys.exit(1)

    except requests.exceptions.HTTPError as err:
        print(f'HTTP error occurred: {err}')
        log.log_error("Generate cid on cpems", message = f"HTTP error occurred: {err}")        
    except requests.exceptions.ConnectionError as err:
        print(f'Connection error occurred: {err}')
        log.log_error("Generate cid on cpems", message = f"Connection error occurred: {err}")        
    except requests.exceptions.Timeout as err:
        print(f'Timeout error occurred: {err}')
        log.log_error("Generate cid on cpems", message = f"Timeout error occurred: {err}")
    except requests.exceptions.RequestException as err:
        print(f'An error occurred: {err}')
        log.log_error("Generate cid on cpems", message = f"An error occurred: {err}")

    log.log_error("Generate cid on cpems", message = "Generate cid on cpems fail")
    sys.exit(1)

def generate_sid_on_cpems(mac: str, model: str) -> None:
    api_key = settings.api_key
    action = "generate_sid"
    try:
        response = requests.post(settings.ott_generate_url.format(api_key=api_key, action= action, mac = mac, serial = mac, model = model), verify=False)
        response.raise_for_status()  # Raise an exception for HTTP errors (4xx and 5xx status codes)
        data = response.json().get('data',{})
        sid = data.get('sid')

        if sid is not None:
            log.log_info("Generate ott sid on cpems", message = "Generate ott sid on cpems success")
            return sid
        else:
            log.log_error("Generate ott sid on cpems", message = "Generate ott sid on cpems fail")
            sys.exit(1)

    except requests.exceptions.HTTPError as err:
        print(f'HTTP error occurred: {err}')
        log.log_error("Generate ott sid on cpems", message = f"HTTP error occurred: {err}")        
    except requests.exceptions.ConnectionError as err:
        print(f'Connection error occurred: {err}')
        log.log_error("Generate ott sid on cpems", message = f"Connection error occurred: {err}")        
    except requests.exceptions.Timeout as err:
        print(f'Timeout error occurred: {err}')
        log.log_error("Generate ott sid on cpems", message = f"Timeout error occurred: {err}")
    except requests.exceptions.RequestException as err:
        print(f'An error occurred: {err}')
        log.log_error("Generate ott sid on cpems", message = f"An error occurred: {err}")

    log.log_error("Generate ott sid on cpems", message = "Generate ott sid on cpems fail")
    sys.exit(1)

def bind_cpe_ott(mac: str,sid: str)-> None:
    output = look_up_from_cpems(mac=mac)
    cid = output.get('cid')
    try:
        response = requests.post(settings.bind_cpe_ott_url.format(cid=cid, sid= sid), verify=False)
        if response.status_code == 200:
            log.log_info("Bind CID and SID on cpems", message = "Bind CID and SID on cpems success")
            return True
        else:
            log.log_error("Bind CID and SID on cpems", message = "Bind CID and SID on cpems fail")
            response.raise_for_status()

    except requests.exceptions.HTTPError as err:
        print(f'HTTP error occurred: {err}')
        log.log_error("Generate ott sid on cpems", message = f"HTTP error occurred: {err}")        
    except requests.exceptions.ConnectionError as err:
        print(f'Connection error occurred: {err}')
        log.log_error("Generate ott sid on cpems", message = f"Connection error occurred: {err}")        
    except requests.exceptions.Timeout as err:
        print(f'Timeout error occurred: {err}')
        log.log_error("Generate ott sid on cpems", message = f"Timeout error occurred: {err}")
    except requests.exceptions.RequestException as err:
        print(f'An error occurred: {err}')
        log.log_error("Generate ott sid on cpems", message = f"An error occurred: {err}")

    log.log_error("Generate ott sid on cpems", message = "Generate ott sid on cpems fail")
    sys.exit(1)

def assign_zone(sid: str)-> None:
    try:
        response = requests.post(settings.assign_zone_url.format(sid=sid), verify=False)
        if response.status_code == 200:
            log.log_info("Assigned zone for OTT", message = "Assigned zone for OTT success")
            return True
        else:
            log.log_error("Assigned zone for OTT", message = "Assigned zone for OTT fail")
            response.raise_for_status()

    except requests.exceptions.HTTPError as err:
        print(f'HTTP error occurred: {err}')
        log.log_error("Assigned zone for OTT", message = f"HTTP error occurred: {err}")        
    except requests.exceptions.ConnectionError as err:
        print(f'Connection error occurred: {err}')
        log.log_error("Assigned zone for OTT", message = f"Connection error occurred: {err}")        
    except requests.exceptions.Timeout as err:
        print(f'Timeout error occurred: {err}')
        log.log_error("Assigned zone for OTT", message = f"Timeout error occurred: {err}")
    except requests.exceptions.RequestException as err:
        print(f'An error occurred: {err}')
        log.log_error("Assigned zone for OTT", message = f"An error occurred: {err}")

    log.log_error("Assigned zone for OTT", message = "Assigned zone for OTT fail")
    sys.exit(1)

def check_ddr(host, username, password):
    with SSH(
        host=host, username=username, password=password
    ) as client:
        output = client.execute("dmesg | grep Clocks", expect_eof=True)
        return output

def uboot_fix(host, username, password):
    with SSH(
        host=host, username=username, password=password
    ) as client:
        client.filecopy_to_device(
            local_file="uboot_fix_fcao_fcgo.tar", to_remote_dir="/tmp/", msg= "Uboot_fix"
        )
        client.execute("cd /tmp/ && tar -xf $patchFile && insmod mtd-rw.ko i_want_a_brick=1 && mtd write openwrt-ar71xx-ap147-16M-qca-legacy-uboot.bin u-boot && reboot && exit", msg="Uboot_fix")


def look_up_from_cpems(mac: str) -> dict:
    try:
        response = requests.get(settings.mac_lookup_url.format(mac=mac))
        if response.status_code == 200:
            return json.loads(response.content)
    except requests.exceptions.HTTPError as err:
        print(f'HTTP error occurred: {err}')
        log.log_error("Check cid on cpems", message = f"HTTP error occurred: {err}")        
    except requests.exceptions.ConnectionError as err:
        print(f'Connection error occurred: {err}')
        log.log_error("Check cid on cpems", message = f"Connection error occurred: {err}")        
    except requests.exceptions.Timeout as err:
        print(f'Timeout error occurred: {err}')
        log.log_error("Check cid on cpems", message = f"Timeout error occurred: {err}")
    except requests.exceptions.RequestException as err:
        print(f'An error occurred: {err}')
        log.log_error("Check cid on cpems", message = f"An error occurred: {err}")

    log.log_info("Check cid on cpems", message = "cid doesn't exit on cpems.")
    return None

def look_up_detail_from_cpems(cid: str) -> dict:
    try:
        response = requests.get(settings.cpe_info_lookup_url.format(cid=cid))
        if response.status_code == 200:
            return json.loads(response.content)
    except requests.exceptions.HTTPError as err:
        print(f'HTTP error occurred: {err}')
        log.log_error("Check cid on cpems", message = f"HTTP error occurred: {err}")        
    except requests.exceptions.ConnectionError as err:
        print(f'Connection error occurred: {err}')
        log.log_error("Check cid on cpems", message = f"Connection error occurred: {err}")        
    except requests.exceptions.Timeout as err:
        print(f'Timeout error occurred: {err}')
        log.log_error("Check cid on cpems", message = f"Timeout error occurred: {err}")
    except requests.exceptions.RequestException as err:
        print(f'An error occurred: {err}')
        log.log_error("Check cid on cpems", message = f"An error occurred: {err}")

    log.log_info("Check cid on cpems", message = "cid doesn't exit on cpems.")
    return None

def config_reset_on_cpems(mac: str) -> None:
    api_key = settings.api_key
    try:
        action = "factory-reset"
        response = requests.get(settings.config_reset_url.format(api_key=api_key,action = action ,mac=mac))
        if response.status_code == 200 and json.loads(response.content)['status'] == "success":
            action = "reset"
            response = requests.get(settings.config_reset_url.format(api_key=api_key,action = action ,mac=mac))
            if response.status_code == 200 and json.loads(response.content)['status'] == "success":
                log.log_info("factory reset on cpems", message = "Make factory reset success.")
            else:
                log.log_info("factory reset on cpems", message = "Make factory reset fail.")

    except requests.exceptions.HTTPError as err:
        print(f'HTTP error occurred: {err}')
        log.log_error("factory reset on cpems", message = f"HTTP error occurred: {err}")        
    except requests.exceptions.ConnectionError as err:
        print(f'Connection error occurred: {err}')
        log.log_error("factory reset on cpems", message = f"Connection error occurred: {err}")        
    except requests.exceptions.Timeout as err:
        print(f'Timeout error occurred: {err}')
        log.log_error("factory reset on cpems", message = f"Timeout error occurred: {err}")
    except requests.exceptions.RequestException as err:
        print(f'An error occurred: {err}')
        log.log_error("factory reset on cpems", message = f"An error occurred: {err}")

def get_cpe_config(mac: str) -> Path:
    config_file = 'cpe_%(mac)s.config' % dict(mac=mac)
    local_cf_dir = "/home/frontiir/resource/configs/"
    status_file = find_file(file_path=local_cf_dir,filename=config_file)
    path_cpe_config = os.path.join(local_cf_dir, config_file)
    if not status_file:
        try:
            res = requests.get(settings.config_download_url.format(mac=mac))
            if res.status_code == 200:
                with open(path_cpe_config, 'wb') as tmpfile:
                    tmpfile.write(res.content)
                return path_cpe_config
            else:
                log.log_error("Apply config", message = "Config file download fail")
                raise FileDownloadFail("Config file download fail.")
        
        except requests.exceptions.HTTPError as err:
            print(f'Apply config. HTTP error occurred: {err}')
            log.log_error("Apply config.", message = f"Apply config fail. HTTP error occurred: {err}")        
        except requests.exceptions.ConnectionError as err:
            print(f'Apply config. Connection error occurred: {err}')
            log.log_error("Apply config.", message = f"Apply config fail.  Connection error occurred: {err}")        
        except requests.exceptions.Timeout as err:
            print(f'Apply config. Timeout error occurred: {err}')
            log.log_error("Apply config.", message = f"Apply config fail. Timeout error occurred: {err}")
        except requests.exceptions.RequestException as err:
            print(f'Apply config. An error occurred: {err}')
            log.log_error("Apply config.", message = f"Apply config fail. An error occurred: {err}")
        return None
    return path_cpe_config

def get_fw_sc_name(model:str ) -> Path:    
    res = requests.get(settings.device_config_url.format(model_name=model))
    if res.status_code != 200:
        raise InvalidResponseException("invalid response code:{}".format(res.status_code))
    if not res.content:
        raise InvalidResponseException("No response body received")
    return res.json()

def find_file(file_path:str , filename:str) -> str:
    # Extract the directory path from the file path
    directory = os.path.dirname(file_path)
    
    # Create the directory if it doesn't exist
    os.makedirs(directory, exist_ok=True)
    
    f = [file for file in os.listdir(file_path) if file == filename]

    return True if len(f) > 0 else False

def get_update_firmware(model: str) -> Path:
    response = get_fw_sc_name(model=model)
    fw_name = response['device_config'][0]['firmware']
    local_fw_dir = "/home/frontiir/resource/firmwares/"
    status_file = find_file(file_path=local_fw_dir,filename=fw_name)
    fw_full_path = local_fw_dir+fw_name
    if not status_file:
        try:
            res = requests.get(settings.file_download_url.format(filename=fw_name))
            if res.status_code == 200:
                with open(fw_full_path,'wb') as file:
                    file.write(res.content)
                return fw_full_path
            else:
                log.log_error("Upgrade firmware", message = "Upgrade firmware file download fail")
                raise FileDownloadFail("Firmware file download fail.")

        except requests.exceptions.HTTPError as err:
            print(f'Upgrade firmware. HTTP error occurred: {err}')
            log.log_error("Upgrade firmware.", message = f"Upgrade firmware fail. HTTP error occurred: {err}")        
        except requests.exceptions.ConnectionError as err:
            print(f'Upgrade firmware. Connection error occurred: {err}')
            log.log_error("Upgrade firmware.", message = f"Upgrade firmware fail.  Connection error occurred: {err}")        
        except requests.exceptions.Timeout as err:
            print(f'Upgrade firmware. Timeout error occurred: {err}')
            log.log_error("Upgrade firmware.", message = f"Upgrade firmware fail. Timeout error occurred: {err}")
        except requests.exceptions.RequestException as err:
            print(f'Upgrade firmware. An error occurred: {err}')
            log.log_error("Upgrade firmware.", message = f"Upgrade firmware fail. An error occurred: {err}")

    return fw_full_path    


def get_update_script(model: str) -> Path:
    response = get_fw_sc_name(model=model)
    sc_name = response['device_config'][0]['client']
    local_sc_dir = "/home/frontiir/resource/scripts/"
    status_file = find_file(file_path=local_sc_dir,filename=sc_name)
    sc_full_path = local_sc_dir+sc_name
    if not status_file:
        try:
            res = requests.get(settings.file_download_url.format(filename=sc_name))
            if res.status_code == 200:
                with open(sc_full_path,'wb') as file:
                    file.write(res.content)
                return sc_full_path
            else:
                log.log_error("Upgrade script", message = "Upgrade firmware file download fail")
                raise FileDownloadFail("Firmware file download fail.")

        except requests.exceptions.HTTPError as err:
            print(f'Upgrade script. HTTP error occurred: {err}')
            log.log_error("Upgrade script.", message = f"Upgrade script fail. HTTP error occurred: {err}")        
        except requests.exceptions.ConnectionError as err:
            print(f'Upgrade script. Connection error occurred: {err}')
            log.log_error("Upgrade script.", message = f"Upgrade script fail.  Connection error occurred: {err}")        
        except requests.exceptions.Timeout as err:
            print(f'Upgrade script. Timeout error occurred: {err}')
            log.log_error("Upgrade script.", message = f"Upgrade script fail. Timeout error occurred: {err}")
        except requests.exceptions.RequestException as err:
            print(f'Upgrade script. An error occurred: {err}')
            log.log_error("Upgrade script.", message = f"Upgrade script fail. An error occurred: {err}")

    return sc_full_path


def get_uniq_pwd(mac: str) -> str:
    valid_pattern = r"^[0-9a-fA-F]+$"

    res = requests.get(settings.uniq_pwd_url.format(mac=mac))
    if res.status_code != 200:
        log.log_error("Unique password.", message = "Unique password fail.")
        raise UniqPasswordGenFail("fail to generate password")
    
    content = res.content.decode().strip()
    if not re.match(valid_pattern, content):
        log.log_error("Unique password.", message = "Invalid password format.")
        raise UniqPasswordGenFail("invalid password format")

    return content


def parse_mac(raw_str: str) -> str:
    pattern = r"([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}"
    match = re.search(pattern, raw_str)
    return match.group() if match else ""


def ping(host: str, count=1, timeout=2, **kwargs) -> bool:
    cmd = f"ping -c {count} -w {timeout} {host}"
    try:
        check_call(shlex.split(cmd), stdout=DEVNULL, stderr=DEVNULL)
    except CalledProcessError:
        return False
    return True


def is_connect(iface: str) -> bool:
    iface_loc = Path(f"/sys/class/net/{iface}")
    if not iface_loc.is_dir():
        return False

    op_state = iface_loc / "operstate"
    state = None
    with open(op_state) as f:
        state = f.read().strip()
    
    if state == "up":
        log.log_info("Check interface", interface = iface, message = f"CPE connect on {iface} interface success.")
    else:
        log.log_error("Check interface", interface = iface, message = f"CPE connect on {iface} interface fail.")
    return True if state == "up" else False


def has_service(host: str, port=22, **kwargs) -> bool:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    is_open = False
    try:
        sock.connect((host, port))
        is_open = True
    except Exception:
        pass
    sock.close()
    return is_open


def until_ok(bool_func: Callable[[Any], bool], *args, timeout=3, **kwargs) -> None:
    wait_timeout = time.time() + timeout  # sec
    flag = "success"
    if bool_func(*args, **kwargs): 
        log.log_info("Device detection", ip = args[0], message = "{} {}".format(kwargs['msg1'],flag))
    while not bool_func(*args, **kwargs):        
        if time.time() > wait_timeout:
            flag = "fail"
            log.log_error("Device detection", ip = args[0], message = "{} {}".format(kwargs['msg1'],flag))
            raise TimeoutError(f"Reached timeout for func ({bool_func.__name__})")
        time.sleep(1)
 

def lookup_mac_with_ip(ipaddr: str, t_sec=2):
    # t_sec means tolerance time for lookup
    if ping(ipaddr, count=t_sec, timeout=t_sec):
        cmd = "arp -a"
        raw_str: str = check_output(shlex.split(cmd)).decode()

        def filter_func(x):
            if "incomplete" not in x and ipaddr in x:
                return True

        raw_str = filter(filter_func, raw_str.splitlines())
        return to_eui(parse_mac("".join(raw_str)))

def get_terminal_mac():
    mac_address = os.environ.get('MAC_ADDRESS')
    if mac_address:
        return mac_address_unix_format(mac_address)
    else:
        output = subprocess.check_output(["ifconfig","enp1s0"]).decode('utf-8')
        mac_address = output.split("ether ")[1].split()[0]
        if mac_address:
            return mac_address_unix_format(mac_address)
        else:
            return None
    
def mac_address_unix_format(mac):
    # Create an EUI object from the MAC address
    mac = EUI(mac, dialect=mac_unix_expanded)
    mac_string = str(mac).replace(":","")
    return mac_string


def provision_cpe_info(mac,serial,model):
    url = settings.cpe_info_url
    terminal_id = get_terminal_mac()
    output = look_up_from_cpems(mac=mac)
    cpe_type = (output.get('cpetype') or '').strip().upper()
    if output and (cid := output.get('cid')):
        payload = {"cid": cid, "mac": mac, "serial": serial, "model": model, "cpe_type": cpe_type}
        headers = {"Content-Type":"application/json","X-Terminal-ID":terminal_id}
        timeout = 5
        bind_contextvars(cid = cid, cpe_type = cpe_type)
        try: 
            response = requests.post(url=url, json=payload, headers=headers, timeout= timeout, verify=False)
            if response.status_code == requests.codes.ok:
                log.log_info("Send provisioning cpe info", cid = cid, cpe_type = cpe_type, message = "Sending cpe provision info success.")
                print("{url} request successful".format(url=url))
            else:
                log.log_error("Send provisioning cpe info", message = "Sending cpe provision info fail.")
                print("{url} request failed with status code:".format(url=url), response.status_code)
        except requests.exceptions.Timeout:
        # Timeout occurred
            log.log_error("Send provisioning cpe info", message = "Request timed out.")
            sys.exit(1) 
        except requests.exceptions.RequestException as e:
            error_message = str(e)
            if "Max retries exceeded with url" in error_message and "Temporary failure in name resolution" in error_message:
                log.log_error("Send provisioning cpe info", message = "Fail to deliver cpe info message.")
                sys.exit(1) 
            else:
                log.log_error("Send provisioning cpe info", message = f"Request error:{error_message}")
                sys.exit(1)

def print_label(mac : str):
    """Print sticker label for CPE
    """
    try:
        response = requests.get(settings.printer_url.format(mac=mac))
        if response.status_code == 200:
            log.log_info("Printing label", message = "Printing label success.")
        else:
            log.log_info("Printing label", message = "Printing label fail.")

    except requests.exceptions.HTTPError as err:
        print(f'HTTP error occurred: {err}')
        log.log_error("Printing label", message = f"HTTP error occurred: {err}")        
    except requests.exceptions.ConnectionError as err:
        print(f'Connection error occurred: {err}')
        log.log_error("Printing label", message = f"Connection error occurred: {err}")        
    except requests.exceptions.Timeout as err:
        print(f'Timeout error occurred: {err}')
        log.log_error("Printing label", message = f"Timeout error occurred: {err}")
    except requests.exceptions.RequestException as err:
        print(f'An error occurred: {err}')
        log.log_error("Printing label", message = f"An error occurred: {err}")
