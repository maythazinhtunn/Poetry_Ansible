import sys
from datetime import datetime
from pcf.strategies.detect import(
    FCPEDetectStrategies,
    ScsoDetectStrategies,
    UbiquitiDetectStrategies,
    Detect_Model_Manager,
)

from pcf.strategies.provision import(
    FCPEProvisionStrategy,
    ScsoProvisionStrategy,
    UBNTProvisionStrategy,
    ProvisionManager,
)

from pcf.utils import (
    is_connect,
    detect_ip,
    )

from pcf.eventlog import Logger
from pcf.config import Settings, get_settings

settings: Settings = get_settings()

model_managers = {
    ("Frontiir Co. Ltd.", "192.168.1.2"): Detect_Model_Manager(FCPEDetectStrategies()),
    ("Frontiir Co. Ltd.", "192.168.99.1"): Detect_Model_Manager(FCPEDetectStrategies()),
    ("Frontiir Co. Ltd.", "192.168.80.1"): Detect_Model_Manager(FCPEDetectStrategies()),
    ("Frontiir Co. Ltd.", "192.168.100.1"): Detect_Model_Manager(FCPEDetectStrategies()),
    ("Frontiir Co. Ltd.", "192.168.1.1"): Detect_Model_Manager(ScsoDetectStrategies()),
    ("Ubiquiti Networks Inc.", "192.168.1.1"): Detect_Model_Manager(UbiquitiDetectStrategies()),
    ("Ubiquiti Networks Inc.", "192.168.1.2"): Detect_Model_Manager(UbiquitiDetectStrategies()),
    ("Ubiquiti Networks Inc.", "192.168.1.20"): Detect_Model_Manager(UbiquitiDetectStrategies()),
    ("Ubiquiti Networks Inc.", "192.168.99.1"): Detect_Model_Manager(UbiquitiDetectStrategies()),
    ("Ubiquiti Networks Inc.", "192.168.100.1"): Detect_Model_Manager(UbiquitiDetectStrategies()),
    # ("Ruckus Wireless", "model_key3"): Detect_Model_Manager(RuckusDetectStrategies()),
}

p_managers = {
    "fcg": ProvisionManager(FCPEProvisionStrategy()),
    "lca-f": ProvisionManager(FCPEProvisionStrategy()),
    "lca-c": ProvisionManager(FCPEProvisionStrategy()),
    "fcs-o": ProvisionManager(FCPEProvisionStrategy()),
    "fcg-e": ProvisionManager(FCPEProvisionStrategy()),
    "fcs": ProvisionManager(FCPEProvisionStrategy()),
    "lcb": ProvisionManager(FCPEProvisionStrategy()),
    "fca-c": ProvisionManager(FCPEProvisionStrategy()),
    "sku1": ProvisionManager(FCPEProvisionStrategy()),
    "fcc": ProvisionManager(FCPEProvisionStrategy()),
    "fcc-e": ProvisionManager(FCPEProvisionStrategy()),
    "fcao": ProvisionManager(FCPEProvisionStrategy()),
    "fcgo": ProvisionManager(FCPEProvisionStrategy()),
    "scso":ProvisionManager(ScsoProvisionStrategy()),
    "nbe-m5-16": ProvisionManager(UBNTProvisionStrategy()),
    "nbe-m5-19": ProvisionManager(UBNTProvisionStrategy()),
    "air-gateway": ProvisionManager(UBNTProvisionStrategy()),
    "air-gateway-lr": ProvisionManager(UBNTProvisionStrategy()),
    "air-router-hp": ProvisionManager(UBNTProvisionStrategy()),
    "air-router": ProvisionManager(UBNTProvisionStrategy()),
    # "er-x-sfp": ProvisionManager(UBNTProvisionStrategy()),
    # "er-x-sfp-r": ProvisionManager(UBNTProvisionStrategy()),
    # "er-x": ProvisionManager(UBNTProvisionStrategy()),
    # "er-x-r": ProvisionManager(UBNTProvisionStrategy()),
}

log: Logger = Logger()

def detect_model():
    # Step1. waiting for cpe connect on iface
    # until_ok(is_connect, settings.cpe_connect_iface, msg1 = "CPE connect on interface")
    is_connect(settings.cpe_connect_iface)
    
    # Step2. detect cpe default ip
    ip,vendor = detect_ip()
    
    # Step3. model detect
    model_detect = model_managers[(vendor,ip)]

    if not model_detect:
        log.log_error("Model detection", message = "Model does not found.")
        sys.exit(1)

    model = model_detect.provision_detect_model(ip)

    if model== "Unknown model":        
        model = model_detect.detect_model(ip)
 
    if model == None :
        log.log_error("Model detection", message = "Model detection fail", ip = ip, product = "", model = "")
    else:
        log.log_info("Model detection", message = "Model detection success", ip = ip, product = vendor, model = model)
    
def provision(model_name: str):
    if model_name not in p_managers:
        raise NotImplementedError

    manager = p_managers.get(model_name)
    manager.make(model_name)

