import click

from pcf.main import start, detect_model


@click.group(invoke_without_command=True, no_args_is_help=True)
@click.version_option(version='1.0.0')
def entrypoint():
    """
    This is the main command

    Usage:\n 
    -provision-ctl detect   Detect frontiir, ubnt device model. \t
    -provision-ctl provision {model name} Provisioning
      
    """
    pass


@entrypoint.command()
def detect():
    print("Start detecting...")
    detect_model()

@entrypoint.command()
@click.argument("model_name", type=click.STRING)
def provision(model_name: str):
    print("Start provisioning...")
    provision(model_name)

if __name__ == "__main__":
    entrypoint()