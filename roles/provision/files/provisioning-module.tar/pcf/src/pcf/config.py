from functools import lru_cache

from pydantic import BaseSettings


class Settings(BaseSettings):
    """Application runtime settings which can be configured via command line or .env file."""

    cpe_connect_iface: str = "enp2s0"
    api_key = ""
    uniq_pwd_url: str = "http://pwdhash.frontiir.net:5101/v1/openwrt?mac={mac}"
    cpe_ip_list : str = "192.168.1.1,192.168.1.2,192.168.1.20,192.168.99.1,192.168.80.1,192.168.100.1"
    cpe_provisioned_ip_list : str = "192.168.99.1,192.168.80.1,192.168.100.1"
    device_config_url = "http://cpe-factory:9999/device_configs?short_code={model_name}"
    file_download_url = "http://cpe-factory:9999/assets/{filename}"
    mac_lookup_url = "http://cpems.frontiir.net/provision/lookupv2/{mac}"
    cpe_info_lookup_url = "http://cpems.frontiir.net:8899/api/v1/cpes/deviceinfo/{cid}"
    cid_generate_url = "https://cpems.frontiir.net:5022/provision/terminalv2/{api_key}/{action}/{mac}/{serial}/{model}"
    ott_generate_url = "http://cpems.frontiir.net:8899/stb/provision/v1/generate_sid/{api_key}/{mac}/{serial}/sat"
    bind_cpe_ott_url = "http://cpems.frontiir.net:8899/stb/provision/v1/bind_sid/{cid}/{sid}"
    assign_zone_url = "http://cpems.frontiir.net:8899/stb/provision/v1/assign_zone/{sid}"
    config_download_url = "http://cpems.frontiir.net/cpe/v1/config?mac={mac}&arg="
    cpe_info_url = "http://example.com/api/v3/events/provisioned"
    config_reset_url = "http://cpems.frontiir.net:8899/api/v1/provision/{action}/{api_key}/{mac}"
    printer_url = "http://print-server:8080/print_label/{mac}"


    class Config:
        env_file = ".env"

@lru_cache
def get_settings() -> Settings:
    return Settings()
