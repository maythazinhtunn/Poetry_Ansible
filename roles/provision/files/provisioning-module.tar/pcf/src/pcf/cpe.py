# module for vendor specific operations
from abc import ABC, abstractmethod
import os
from pcf.ssh import SSH
from pcf.eventlog import Logger

log: Logger = Logger()
class CPE(ABC):
    @abstractmethod
    def detect_model(self):
        raise NotImplementedError
    
    @abstractmethod
    def upgrade_firmware(self, fw_file: str):
        raise NotImplementedError

    @abstractmethod
    def upgrade_script(self, sc_file: str):
        raise NotImplementedError

    @abstractmethod
    def clear_script(self):
        raise NotImplementedError

    @abstractmethod
    def apply_config(self, config_file: str):
        raise NotImplementedError

    @abstractmethod
    def lock_device(self, uniq_password: str):
        raise NotImplementedError
    
    @abstractmethod
    def reboot_device(self,ip: str, password: str):
        raise NotImplementedError
    
class FRONTIIR_CPE(CPE):
    def __init__(self, host, ssh_user="root", ssh_password="7890") -> None:
        self.host = host
        self.ssh_user = ssh_user
        self.ssh_password = ssh_password

    def detect_model(self): 
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.login()
            res = client.execute("cat /tmp/sysinfo/model")
            model_info_list = res.split()
            model = model_info_list[4]            
            return model

    def upgrade_firmware(self, fw_file: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            fw_name = os.path.basename(fw_file)
            client.filecopy_to_device(local_file=fw_file, to_remote_dir="/tmp/", msg= "Upgrade firmware")          
            client.execute("sysupgrade -v /tmp/%(firmware)s &" % dict(firmware=fw_name), msg= "Upgrade firmware %(firmware)s &" % dict(firmware=fw_name))

    def upgrade_script(self, sc_file: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            sc_name = os.path.basename(sc_file)
            client.filecopy_to_device(local_file=sc_file, to_remote_dir="/tmp/", msg= "Upgrade script")
            client.execute("tar -xvf /tmp/%(script)s -C /"% dict(script=sc_name), msg= "Upgrade script %(script)s"% dict(script=sc_name))

    def clear_script(self):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.execute("rm -rf /overlay/upper")
            client.execute("reboot", expect_eof=True)

    def apply_config(self, config_file: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.filecopy_to_device(
                local_file=config_file, to_remote_dir="/root/scripts/cfg/cpe.factory", msg= "Apply config"
            )

    def lock_device(self, uniq_password: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.set_new_password(new_password=uniq_password)
            client.execute("cp -p /overlay/upper/etc/shadow /root/scripts/cfg/shadow", msg="Set unique password")
    
    def reboot_device(self,ip: str, password: str):
        with SSH(
            host=ip, username=self.ssh_user, password=password
        ) as client:
            client.execute("reboot", expect_eof=True)
    
class UBNT_CPE(CPE):
    def __init__(self, host, ssh_user="root", ssh_password="letmein") -> None:
        self.host = host
        self.ssh_user = ssh_user
        self.ssh_password = ssh_password

    def detect_model(self): 
        raise NotImplementedError

    def upgrade_firmware(self, fw_file: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            fw_name = os.path.basename(fw_file)
            client.filecopy_to_device(local_file=fw_file, to_remote_dir="/tmp/", msg= "Upgrade firmware")          
            client.execute("sysupgrade -v /tmp/%(firmware)s &" % dict(firmware=fw_name), msg= "Upgrade firmware %(firmware)s &" % dict(firmware=fw_name))

    def upgrade_script(self, sc_file: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            sc_name = os.path.basename(sc_file)
            client.filecopy_to_device(local_file=sc_file, to_remote_dir="/tmp/", msg= "Upgrade script")
            client.execute("tar -xvf /tmp/%(script)s -C /"% dict(script=sc_name), msg= "Upgrade script %(script)s"% dict(script=sc_name))

    def clear_script(self):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.execute("rm -rf /overlay/upper")
            client.execute("reboot", expect_eof=True)

    def apply_config(self, config_file: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.filecopy_to_device(
                local_file=config_file, to_remote_dir="/root/scripts/cfg/cpe.factory", msg= "Apply config"
            )

    def lock_device(self, uniq_password: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.set_new_password(new_password=uniq_password)
            client.execute("cp -p /overlay/upper/etc/shadow /root/scripts/cfg/shadow", msg="Set unique password")
    
    def reboot_device(self,ip: str, password: str):
        with SSH(
            host=ip, username=self.ssh_user, password=password
        ) as client:
            client.execute("reboot", expect_eof=True)
    
class SCSO_CPE(CPE):
    def __init__(self, host, ssh_user="root", ssh_password="7890") -> None:
        self.host = host
        self.ssh_user = ssh_user
        self.ssh_password = ssh_password

    def detect_model(self): 
        raise NotImplementedError

    def upgrade_firmware(self, fw_file: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            fw_name = os.path.basename(fw_file)
            client.filecopy_to_device(local_file=fw_file, to_remote_dir="/tmp/", msg= "Upgrade firmware")   
            client.execute("tcapi set System_Entry upgrade_fw 1",  msg= "Upgrade firmware %(firmware)s &" % dict(firmware=fw_name))
            client.execute("tcapi commit System_Entry", msg= "Upgrade firmware %(firmware)s &" % dict(firmware=fw_name))       

    def upgrade_script(self, sc_file: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            sc_name = os.path.basename(sc_file)
            client.filecopy_to_device(local_file=sc_file, to_remote_dir="/tmp/", msg= "Upgrade script")
            client.execute("tar -xvf /tmp/%(script)s -C /"% dict(script=sc_name), msg= "Upgrade script %(script)s"% dict(script=sc_name))

    def clear_script(self):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.execute("rm -rf /usr/mnt/*")
            client.execute("prolinedcmd restore default", expect_eof=True)

    def apply_config(self, config_file: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.filecopy_to_device(
                local_file=config_file, to_remote_dir="/root/scripts/cfg/cpe.factory", msg= "Apply config"
            )

    def lock_device(self, uniq_password: str):
        with SSH(
            host=self.host, username=self.ssh_user, password=self.ssh_password
        ) as client:
            client.set_new_password(new_password=uniq_password)
            client.execute("cp -p /overlay/upper/etc/shadow /root/scripts/cfg/shadow", msg="Set unique password")
    
    def reboot_device(self,ip: str, password: str):
        with SSH(
            host=ip, username=self.ssh_user, password=password
        ) as client:
            client.execute("reboot", expect_eof=True)
    
class RUCKUS_CPE(CPE):
    def detect_model(self):
        raise NotImplementedError
    
    def upgrade_firmware(self, fw_file: str):
        raise NotImplementedError

    def upgrade_script(self, sc_file: str):
        raise NotImplementedError

    def clear_script(self):
        raise NotImplementedError

    def apply_config(self, config_file: str):
        raise NotImplementedError

    def lock_device(self, uniq_password: str):
        raise NotImplementedError
    
    def reboot_device(self,ip: str, password: str):
        raise NotImplementedError