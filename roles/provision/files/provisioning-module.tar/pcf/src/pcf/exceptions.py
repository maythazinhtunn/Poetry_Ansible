class LoginFail(Exception):
    pass


class ExecuteCommandFail(Exception):
    pass

class InvalidResponseException(Exception):
    pass

class SetPasswordFail(Exception):
    pass


class FileCopyFail(Exception):
    pass


class UniqPasswordGenFail(Exception):
    pass

class DetectDeviceFail(Exception):
    pass

class FileDownloadFail(Exception):
    pass