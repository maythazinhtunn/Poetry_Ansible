from pcf import __version__
from pcf.config import Settings, get_settings


def test_package_version():
    assert __version__ == "0.1.0"


def test_config():
    assert isinstance(get_settings(), Settings)
