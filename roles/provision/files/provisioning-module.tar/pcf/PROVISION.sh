#!/bin/bash
poetry run provision-ctl detect
model=$(poetry run provision-ctl detect | grep 'model' | awk '{print $11}' | sed 's/["\,]//g')
if [ ! -z "$model" ]; then
    poetry run provision-ctl provision $model
else
    echo "cpe model doesn't exit"
fi
